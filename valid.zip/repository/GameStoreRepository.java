package br.edu.unifacisa.repository;

import java.util.List;
import java.util.Optional;

import br.edu.unifacisa.model.DataBase;
import br.edu.unifacisa.model.GameStore;


public class GameStoreRepository {
	private List<GameStore> jogos;
	
	public GameStoreRepository() {
		this.jogos = DataBase.getInstance().jogos();
	}
	
	public void cadastrar(GameStore jogo) {
		jogos.add(jogo);
	}
	public List<GameStore> listar(){
		return jogos;
	}

	public void remover(int id){
		jogos.remove(obterJogo(id));
	}
	
	public GameStore obterJogo(int id){
		Optional<GameStore> jogoEncontrado = jogos.stream().filter(j -> j.getId() ==id).findFirst();
		return jogoEncontrado.isPresent() ? jogoEncontrado.get(): null;
	}
	
	public GameStore editar(GameStore jogo, int id) throws Exception{
		GameStore jogoParaEditar = obterJogo(id);
		if (jogoParaEditar == null) {
			throw new Exception("jogo nao encontrado!");
		}
		jogoParaEditar.setImagem(jogo.getImagem());
		jogoParaEditar.setPreco(jogo.getPreco());
		jogoParaEditar.setTitulo(jogo.getTitulo());
		return jogoParaEditar;
	}
	
	public GameStore realizarVenda(int id) throws Exception{
		GameStore jogoParaVender= obterJogo(id);
		if (jogoParaVender == null) {
			throw new Exception("jogo nao encontrado!");
		}
		jogoParaVender.setNumeroDeVendas(jogoParaVender.getNumeroDeVendas()+1);
		return jogoParaVender;
		
	}

}
