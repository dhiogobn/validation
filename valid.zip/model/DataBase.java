package br.edu.unifacisa.model;

import java.util.ArrayList;
import java.util.List;

public class DataBase {
	public static DataBase instancia;
	private List<GameStore> jogos = new ArrayList<GameStore>();
	
	public static DataBase getInstance() {
		if(instancia == null) {
			instancia = new DataBase();
		}
		
		return instancia;
	}	
	public List<GameStore> jogos(){
		return jogos;
	}

}
