package br.edu.unifacisa.model;

import javax.validation.constraints.NotEmpty;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor @NoArgsConstructor
public class GameStore {
	private int id;
	@NotEmpty(message = "campo obrigatorio")
	private String titulo;
	@NotEmpty(message = "campo obrigatorio")
	private String imagem;
	private double preco;
	private long numeroDeVendas;
}
